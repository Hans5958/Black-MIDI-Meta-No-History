using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Graphics;
using ScriptedEngine;
using ZenithEngine;

public class Script
{
    public string Description = "Notes bouce off of the ground (customizable)";
    public string Preview = "preview.png";

    UINumberSlider kbWidth = new UINumberSlider("Width", 0.2, 0.1, 1, 0.01, 1, 2, false);
    UINumberSlider gHeight = new UINumberSlider("Ground Height", 0.15, 0, 1, 0, 1, 2, false);
    UINumberSlider scatterSpread = new UINumberSlider("Scatter Spread", 0.8, 0, 1, 0, 1, 2, false);
    UINumberSlider randomness = new UINumberSlider("Scatter Randomness", 0.8, 0, 1, 0, 1, 2, false);
    UINumberSlider darkenNotes = new UINumberSlider("Darken Hit Notes", 0.8, 0, 1, 0, 1, 2, false);
    UINumberSlider noteVelocity = new UINumberSlider("Velocity", 1, 0.1, 3, 0.1, 10, 2, false);
    UIDropdown hasGravity = new UIDropdown("Physics", new[] { "Linear", "Gravity" });
    UINumberSlider gravity = new UINumberSlider("Gravity Strength", 1, -1, 4, -10, 10, 2, false);
    UICheckbox scatterOnly = new UICheckbox("Only render scatter", false);

    public UISetting[] SettingsUI;
    public bool ManualNoteDelete = true;
    public long LastNoteCount = 0;

    public bool UseProfiles = true;

    Random r = new Random();

    public void Load()
    {
        SettingsUI = new UISetting[]{
            kbWidth,
            gHeight,
            scatterSpread,
            randomness,
            darkenNotes,
            noteVelocity,
            hasGravity,
            gravity,
            scatterOnly
        };
        // This script doesn't require any loading    
    }

    public void Render(IEnumerable<Note> notes, RenderOptions options)
    {
        double keyboardHeight = gHeight.Value;

        bool linear = hasGravity.Index == 0;
        double darkenHitNotes = darkenNotes.Value;
        double segmentSize = 0.01;
        double noteVel = noteVelocity.Value;
        double spread = scatterSpread.Value;
        double randomFactor = randomness.Value;

        // The variables below are used to convert notes from tick positions to screen position
        // It's calculated here rather than each time a note is drawn for optimization
        double notePosFactor = 1 / options.noteScreenTime * (1 - keyboardHeight);
        double renderCutoff = options.midiTime + options.noteScreenTime;

        // The keyboard layout, each key's and note's left and right edges as well as some other metadata
        var layout = Util.GetKeyboardLayout(options.firstKey, options.lastKey, new KeyboardOptions() { sameWidthNotes = true });

        LastNoteCount = 0;

        Color4 darkenBlend = new Color4(0, 0, 0, (float)(darkenHitNotes));

        // Loop over each note
        foreach (var note in notes)
        {
            // If a note is above or below the view, skip it.
            if (note.start > renderCutoff) continue;
            LastNoteCount++;

            // Get the coordinates of the note's edges
            double top = 1 - (renderCutoff - note.end) * notePosFactor;
            double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
            double left = layout.keys[note.key].left;
            double right = layout.keys[note.key].right;
            // If a note hasn't ended, set it's top coordinate to the top of the screen
            if (!note.hasEnded) top = 1;

            left = (left - 0.5) * kbWidth.Value + 0.5;
            right = (right - 0.5) * kbWidth.Value + 0.5;

            int keyRange = options.lastKey - options.firstKey;

            // Check if the note is touching the keyboard
            if (note.start < options.midiTime)
            {
                Color4 leftCol = Util.BlendColors(note.color.left, darkenBlend);
                Color4 rightCol = Util.BlendColors(note.color.right, darkenBlend);

                if (note.meta == null) note.meta = r.NextDouble() * 2 - 1;
                double randomAng = (double)note.meta;

                double trueAng = -((note.key - options.firstKey) / (double)(keyRange)) * 2 + 1;
                double ang = trueAng * (1 - randomFactor) + randomAng * randomFactor;
                ang = ang * Math.PI / 2 * spread + Math.PI / 2;

                double start = keyboardHeight - bottom;
                double length = start;
                double end = keyboardHeight - top;
                if (end > 0) length -= end;
                else end = 0;

                double halfWidth = (right - left) / 2;
                Vector2d direction = new Vector2d(Math.Cos(ang), Math.Sin(ang));
                Vector2d normal = new Vector2d(direction.Y, -direction.X * options.renderAspectRatio);
                direction.X /= options.renderAspectRatio;
                Vector2d lineStart = new Vector2d((left + right) / 2, keyboardHeight);

                if (linear)
                {
                    Vector2d blockStart = lineStart + direction * start;
                    Vector2d blockEnd = lineStart + direction * end;

                    if (blockEnd.X < 0 || blockEnd.X > 1 || blockEnd.Y > 1)
                    {
                        note.delete = true;
                        continue;
                    }

                    IO.RenderShape(
                        blockStart + normal * halfWidth,
                        blockStart - normal * halfWidth,
                        blockEnd - normal * halfWidth,
                        blockEnd + normal * halfWidth,
                        leftCol,
                        rightCol,
                        rightCol,
                        leftCol
                    );
                }
                else
                {
                    var cos = Math.Cos(ang);
                    var sin = Math.Sin(ang);
                    var cosSquared = cos * cos;
                    var velSquared = noteVel * noteVel;

                    var g = gravity.Value;

                    var extra = length % segmentSize;
                    var endPos = getPos(end, noteVel, cos, sin, g);
                    endPos.X /= options.renderAspectRatio;
                    var endNormal = getNormal(end, noteVel, cos, sin, g);
                    endNormal.Y *= options.renderAspectRatio;

                    endPos += lineStart;

                    Vector2d prevPos = endPos + lineStart;
                    Vector2d prevCornerTop = endPos + endNormal * halfWidth;
                    Vector2d prevCornerBottom = endPos - endNormal * halfWidth;

                    for (double t = end + extra; t <= start; t += segmentSize)
                    {
                        if (prevPos.Y < keyboardHeight - 0.00001) break;
                        var tPos = getPos(t, noteVel, cos, sin, g);
                        tPos.X /= options.renderAspectRatio;
                        tPos += lineStart;
                        var tNormal = getNormal(t, noteVel, cos, sin, g);
                        tNormal.Y *= options.renderAspectRatio;
                        Vector2d cornerTop = tPos + tNormal * halfWidth;
                        Vector2d cornerBottom = tPos - tNormal * halfWidth;

                        IO.RenderShape(
                            prevCornerTop,
                            prevCornerBottom,
                            cornerBottom,
                            cornerTop,
                            leftCol,
                            rightCol,
                            rightCol,
                            leftCol
                        );

                        prevCornerTop = cornerTop;
                        prevCornerBottom = cornerBottom;
                        prevPos = tPos;
                    }

                    if (endPos.X < 0 || endPos.X > 1 || (endPos.Y < keyboardHeight || (g <= 0 && endPos.Y > 1)))
                    {
                        note.delete = true;
                        continue;
                    }
                }
            }
        }

        if (!scatterOnly.Checked)
        {
            // Loop over each note
            foreach (var note in notes)
            {
                // If a note is above or below the view, skip it.
                if (note.hasEnded && note.end < options.midiTime || note.start > renderCutoff) continue;

                // Get the coordinates of the note's edges
                double top = 1 - (renderCutoff - note.end) * notePosFactor;
                double bottom = 1 - (renderCutoff - note.start) * notePosFactor;
                double left = layout.keys[note.key].left;
                double right = layout.keys[note.key].right;
                // If a note hasn't ended, set it's top coordinate to the top of the screen
                if (!note.hasEnded) top = 1;

                left = (left - 0.5) * kbWidth.Value + 0.5;
                right = (right - 0.5) * kbWidth.Value + 0.5;

                // Render the note, with gradient color
                if (top > keyboardHeight)
                    IO.RenderQuad(left, top, right, Math.Max(bottom, keyboardHeight), note.color.left, note.color.right, note.color.right, note.color.left);
            }
        }

        IO.RenderQuad(0, keyboardHeight, 1, 0, new Color4(100, 100, 100, 255));
    }

    Vector2d getPos(double t, double v, double cos, double sin, double g)
    {
        return new Vector2d(v * t * cos, v * t * sin - g * t * t / 2);
    }

    Vector2d getNormal(double t, double v, double cos, double sin, double g)
    {
        var tangent = getPos(t, v, cos, sin, g) - getPos(t - 0.001, v, cos, sin, g);
        return new Vector2d(tangent.Y, -tangent.X).Normalized();
    }
}